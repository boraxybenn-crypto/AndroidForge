package com.example.icefishing

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "ICE FISHING ANALYZER"
            textSize = 24f
            setPadding(0, 0, 0, 20)
        }
        status = TextView(this).apply {
            text = "Ready. Start monitoring, then switch to Chrome."
            textSize = 16f
            setPadding(0, 0, 0, 20)
        }
        val overlay = Button(this).apply {
            text = "1. Grant floating-window permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "Floating-window permission granted."
            }
        }
        val start = Button(this).apply {
            text = "2. Start screen monitoring"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "Grant floating-window permission first."
                    return@setOnClickListener
                }
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        }
        val stop = Button(this).apply {
            text = "Stop monitoring"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)); status.text = "Monitoring stopped." }
        }
        layout.addView(title); layout.addView(status); layout.addView(overlay)
        layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }

    @Deprecated("Use activity result API in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            startForegroundService(service)
            status.text = "Screen monitoring active. Switch to Chrome. Android shows a persistent capture notification."
        } else status.text = "Screen capture was not authorised."
    }
}
