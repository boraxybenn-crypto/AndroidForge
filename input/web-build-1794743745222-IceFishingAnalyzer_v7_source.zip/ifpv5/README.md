# Ice Fishing Analyzer v7 — source project

**This is source code, not an APK.** It must be built with Android Studio or a trusted Android build environment.

## Changes in v7
- Keeps the MediaProjection screen-capture workflow and floating overlay from v6.
- Adds a clearly labelled *historical leader* line after at least five fish-category OCR records have been stored.
- Displays the most frequent recorded category and its share of the recorded observations.
- Below five stored observations it displays the number still needed instead of inventing an estimate.

## Important: what it cannot do
- It cannot know or reliably predict the next casino result. An independent RNG outcome is not inferable from previous rounds.
- The “historical leader” is a descriptive frequency summary, **not a next-round prediction or betting signal**.
- The current OCR detector is experimental. It looks for a multiplier and a fish/leaf label in the same OCR line, then requires three stable frames. Your supplied video did not show a clear sequence of completed result screens: it mainly showed low-balance popups, the betting screen, app switching, and monitoring controls. Therefore the actual game-result detector remains unvalidated and may still record zero results.
- This version does not reliably recognise the graphic leaf icon or fish artwork. OCR cannot identify every image symbol.
- It does not connect to the casino server, inspect hidden game state, or bypass game controls.
- Do not use the output to place bets or risk money.

## Permissions and privacy
- Android screen capture requires explicit consent each time monitoring starts.
- Floating overlay permission is required to show the panel over Chrome.
- OCR is processed on-device by ML Kit. The app requests no network permission; result history is stored in private app preferences.
- Screen capture can expose anything visible on the phone while enabled. Stop monitoring when finished.

## Build
1. Open this project in Android Studio on a computer.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Review the generated APK before installing. If Play Protect warns that it is harmful, do not bypass the warning; stop and inspect the APK/source first.

Minimum Android: 8.0 (API 26). Compile/target SDK: 35. Java/Kotlin target: 17.

## Use
1. Open Ice Fishing Analyzer.
2. Grant “Display over other apps”.
3. Tap “Start screen monitoring” and approve Android's screen-capture prompt.
4. Switch to Chrome and open the game. Keep the game visible and awake.
5. The overlay shows OCR detections, counts and (after five detections) the historical frequency leader.
6. Return to the app and tap Stop monitoring when finished.

## Validation required
Before trusting even the historical counts, compare every detected item against the game’s actual completed round. The OCR detector can mistake text on the wheel or miss graphic-only results. This prototype is not production-ready.
