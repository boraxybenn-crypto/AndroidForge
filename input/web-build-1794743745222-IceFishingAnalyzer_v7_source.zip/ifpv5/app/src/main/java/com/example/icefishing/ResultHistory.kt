package com.example.icefishing

import android.content.Context

object ResultHistory {
    private const val PREFS = "results"
    private const val KEY_ROWS = "rows"
    private val fishNames = listOf("LIL' BLUES", "BIG ORANGES", "HUGE REDS")

    fun add(context: Context, kind: String, label: String, multiplier: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString(KEY_ROWS, "") ?: ""
        val safeLabel = label.replace("|", " ").replace("\n", " ")
        val safeMultiplier = multiplier.replace("|", "")
        val row = "${System.currentTimeMillis()}|$kind|$safeLabel|$safeMultiplier"
        prefs.edit().putString(KEY_ROWS, (old + row + "\n").takeLast(100_000)).apply()
    }

    private fun rows(context: Context): List<List<String>> =
        (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ROWS, "") ?: "")
            .lineSequence().filter { it.isNotBlank() }.map { it.split("|") }.toList()

    fun fishCounts(context: Context): Map<String, Int> {
        val counts = fishNames.associateWith { 0 }.toMutableMap()
        rows(context).forEach { row ->
            if (row.getOrNull(1) == "FISH") {
                val label = row.getOrNull(2)
                if (label in counts) counts[label!!] = counts.getValue(label) + 1
            }
        }
        return counts
    }

    fun multiplierCounts(context: Context, kind: String): Map<String, Int> {
        val counts = sortedMapOf<String, Int>(compareBy { it.removeSuffix("x").toDoubleOrNull() ?: Double.MAX_VALUE })
        rows(context).forEach { row ->
            if (row.getOrNull(1) == kind) {
                val multiplier = row.getOrNull(3)
                if (!multiplier.isNullOrBlank()) counts[multiplier] = (counts[multiplier] ?: 0) + 1
            }
        }
        return counts
    }

    /** Descriptive frequency leader only; this is not a forecast of an RNG result. */
    fun historicalLeader(context: Context): String {
        val counts = fishCounts(context)
        val total = counts.values.sum()
        if (total < 5) return "Insufficient verified results ($total/5)"
        val leader = counts.entries.maxByOrNull { it.value } ?: return "Insufficient verified results"
        val pct = leader.value * 100.0 / total
        return "Historical leader: ${leader.key} (${String.format(java.util.Locale.US, "%.1f", pct)}%)"
    }

    fun fishTotal(context: Context): Int = fishCounts(context).values.sum()

    fun total(context: Context): Int = rows(context).size
}
