# Ice Fishing Analyzer v6 — diagnostic source prototype

This is an Android Studio source project, not an APK. It has not been compiled or device-tested here.

## What changed from v5
- Keeps user-approved MediaProjection capture and the floating overlay.
- Keeps on-device ML Kit OCR and local-only processing (no INTERNET permission is declared).
- Adds a visible screen-phase diagnostic based on readable phrases such as “PLACE YOUR BETS” and “NEXT GAME SOON”.
- Shows a short OCR text sample in the overlay so we can see what ML Kit actually reads on the user's device.
- Labels stored detections as unverified OCR matches, not confirmed winning outcomes.
- Bumps app version to 6.0-diagnostic.

## Critical limitations
- The screenshots show multiplier values printed on moving wheel segments. OCR reading a fish label and a multiplier does not prove that segment won.
- Leaf icons are graphics, not the words “leaf” or “leaves”; this source does not yet perform validated graphical leaf classification.
- The game screenshots do not provide an unambiguous completed-result panel. Without a verified result state or manually labelled completed-round examples, automatic outcome counting cannot be validated.
- The app cannot access the casino backend, hidden RNG, or predict future independent outcomes. Do not use its output to make bets.
- Screen capture can expose everything visible on the phone. Start only when comfortable; Android requires explicit consent. Stop monitoring from the app when finished.

## Build and test
Open the project in Android Studio, sync Gradle, and build a debug APK. This archive has not been compiled in this environment. Before installing, review Android's permission prompts and do not bypass Google Play Protect warnings.

## Test protocol
Run it only in non-wagering observation. Compare the overlay's OCR sample and phase label against the visible screen. Record whether “PLACE YOUR BETS” appears after a completed spin and whether a separate result panel/text exists. A screenshot of the completed result is required before implementing and validating a true round-result classifier.
