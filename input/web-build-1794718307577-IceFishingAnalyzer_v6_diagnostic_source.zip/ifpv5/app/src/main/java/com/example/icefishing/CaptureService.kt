package com.example.icefishing

import android.app.*
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private val busy = AtomicBoolean(false)
    // A result is accepted only after the same OCR fingerprint is stable for
    // several frames, and only once until the result text disappears/changes.
    private var candidateFingerprint = ""
    private var candidateFrames = 0
    private var acceptedFingerprint = ""
    private var lastFrameAt = 0L
    private var lastOcrSummary = "Waiting for screen text…"
    private var gamePhase = "UNKNOWN"
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(7, NotificationCompat.Builder(this, "capture")
            .setContentTitle("Ice Fishing Analyzer")
            .setContentText("Screen analysis is active. Tap Stop in the app to end it.")
            .setSmallIcon(android.R.drawable.ic_menu_search).setOngoing(true).build())

        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("projectionData", Intent::class.java)
        else @Suppress("DEPRECATION") (intent?.getParcelableExtra("projectionData") as? Intent)

        if (code == Activity.RESULT_OK && data != null) beginCapture(code, data)
        return START_NOT_STICKY
    }

    private fun beginCapture(code: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            val now = android.os.SystemClock.elapsedRealtime()
            // Limit OCR frequency to reduce battery/CPU use; always close skipped frames.
            if (now - lastFrameAt < 1200L || !busy.compareAndSet(false, true)) {
                image.close()
            } else {
                lastFrameAt = now
                analyse(image)
            }
        }, null)
        display = projection?.createVirtualDisplay("IceFishingCapture", width, height,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null)
        showOverlay()
    }

    private fun analyse(image: Image) {
        val bitmap = image.toBitmap()
        image.close()
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val rawText = result.text
                val text = rawText.lowercase()
                // Phase labels are diagnostic only. They do not establish a winning result.
                gamePhase = when {
                    text.contains("place your bets") -> "BETTING PHASE"
                    text.contains("next game soon") -> "NEXT GAME / SPIN TRANSITION"
                    else -> "WHEEL / OTHER SCREEN"
                }
                lastOcrSummary = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }
                    .take(5).joinToString(" | ").take(180).ifBlank { "No readable text" }
                // Keep the old conservative OCR candidate parser for diagnostic comparison.
                // Wheel labels/multipliers can be printed on separate segments, so a match
                // is not proof of a completed round and must not be treated as prediction.
                val lines = rawText.lines().map { it.lowercase() }
                var multiplier: String? = null
                var leafHit = false
                var fishLabel: String? = null
                for (line in lines) {
                    val m = Regex("\\b\\d+(?:\\.\\d+)?\\s*x\\b", RegexOption.IGNORE_CASE).find(line)?.value?.replace(" ", "")
                    if (m != null && Regex("\\b(leaf|leaves)\\b", RegexOption.IGNORE_CASE).containsMatchIn(line)) {
                        multiplier = m; leafHit = true; fishLabel = null; break
                    }
                    if (m != null) {
                        val label = when {
                            Regex("\\b(lil.? blues|blue|blues)\\b").containsMatchIn(line) -> "LIL' BLUES"
                            Regex("\\b(big oranges|orange|oranges)\\b").containsMatchIn(line) -> "BIG ORANGES"
                            Regex("\\b(huge reds|red|reds)\\b").containsMatchIn(line) -> "HUGE REDS"
                            else -> null
                        }
                        if (label != null) { multiplier = m; fishLabel = label; leafHit = false; break }
                    }
                }
                val validResult = multiplier != null && (leafHit || fishLabel != null)
                val fingerprint = if (validResult)
                    "${if (leafHit) "LEAF" else "FISH"}|${fishLabel ?: ""}|${multiplier ?: ""}"
                    else ""

                if (fingerprint.isEmpty()) {
                    // Seeing no complete result rearms the detector for the next round.
                    candidateFingerprint = ""
                    candidateFrames = 0
                    acceptedFingerprint = ""
                    updateOverlay(null)
                } else {
                    if (fingerprint == candidateFingerprint) candidateFrames++
                    else {
                        candidateFingerprint = fingerprint
                        candidateFrames = 1
                    }
                    // Three consecutive matching frames reduce transient OCR noise.
                    if (candidateFrames >= 3 && fingerprint != acceptedFingerprint) {
                        acceptedFingerprint = fingerprint
                        if (leafHit) ResultHistory.add(this, "LEAF", "LEAF", multiplier!!)
                        else if (fishLabel != null) ResultHistory.add(this, "FISH", fishLabel, multiplier!!)
                        updateOverlay(if (leafHit) "LEAF $multiplier" else "$fishLabel $multiplier")
                    } else updateOverlay(null)
                }
            }
            .addOnCompleteListener { bitmap.recycle(); busy.set(false) }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "ICE FISHING ANALYZER\nCollecting visible results…"
            textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD152B3A.toInt()); setPadding(18, 14, 18, 14)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        windowManager?.addView(overlay, params)
        updateOverlay(null)
    }

    private fun updateOverlay(detected: String?) {
        val fish = ResultHistory.fishCounts(this)
        val fishTotal = fish.values.sum()
        val leafMultipliers = ResultHistory.multiplierCounts(this, "LEAF")
        val fishMultipliers = ResultHistory.multiplierCounts(this, "FISH")
        fun format(map: Map<String, Int>): String = if (map.isEmpty()) "No multiplier results detected yet"
            else map.entries.joinToString("  ") { "${it.key}: ${it.value}" }
        val fishLines = fish.map { (name, count) ->
            val pct = if (fishTotal == 0) 0 else count * 100 / fishTotal
            "$name  $count ($pct%)"
        }
        overlay?.post {
            overlay?.text = (if (detected != null) "LAST DETECTED: $detected\n" else "") +
                "ICE FISHING — LIVE SCREEN ANALYSIS\n" +
                "FISH RESULTS (historical)\n" + fishLines.joinToString("\n") +
                "\n\nLEAF MULTIPLIERS\n${format(leafMultipliers)}" +
                "\n\nFISH MULTIPLIERS\n${format(fishMultipliers)}" +
                "\n\nRecorded OCR matches (unverified): ${ResultHistory.total(this)}" +
                "\nScreen phase: $gamePhase" +
                "\nOCR sample: $lastOcrSummary" +
                "\nObservations only — not verified outcomes or predictions"
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("capture", "Screen analysis", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { windowManager?.removeView(overlay) } catch (_: Exception) {}
        display?.release(); reader?.close(); projection?.stop(); recognizer.close()
        super.onDestroy()
    }
}

// RGBA_8888 ImageReader frame to Bitmap.
private fun Image.toBitmap(): android.graphics.Bitmap {
    val plane = planes[0]
    val buffer = plane.buffer
    val pixelStride = plane.pixelStride
    val rowStride = plane.rowStride
    val rowPadding = rowStride - pixelStride * width
    val padded = android.graphics.Bitmap.createBitmap(width + rowPadding / pixelStride, height,
        android.graphics.Bitmap.Config.ARGB_8888)
    padded.copyPixelsFromBuffer(buffer)
    return android.graphics.Bitmap.createBitmap(padded, 0, 0, width, height).also { padded.recycle() }
}
