# Ice Fishing Analyzer — Android starter project

This is a source project, not a prebuilt APK. Open the folder in Android Studio and build an APK.

## What this prototype does
- Requests Android's screen-capture consent through MediaProjection.
- Runs a foreground capture service while the user has authorised it.
- Displays a floating overlay over Chrome (requires "Display over other apps").
- Uses on-device ML Kit OCR to look for result-feed text containing both a multiplier (for example `4x`) and a category name.
- Stores recognised categories locally and displays their historical frequency.

## Important limitations
- This is an experimental OCR prototype. It does not connect to the casino backend, inspect hidden game state, bypass login/session controls, or predict a future RNG outcome.
- The game wheel itself continuously contains all three category labels. To reduce false positives, the prototype only records OCR text when it sees both a multiplier and a category. The feed may still produce false detections; validate the history before relying on it.
- Percentages shown in the overlay are historical frequencies, explicitly not forecasts or betting advice.
- Android requires the user to approve screen capture each time the capture session is started. Android may stop capture when the app/session is closed.
- Screen capture can expose sensitive information on screen. Only enable it while you are comfortable sharing the visible screen with this local app. OCR is processed on-device.
- The service currently uses a simple full-screen OCR pass. A production version should crop the result-feed region, add a user calibration screen, improve round-boundary detection, and provide a full in-app history dashboard/export.

## Build
1. Install Android Studio on a computer.
2. Open this project folder.
3. Allow Gradle sync and install the Android SDK 35 platform if prompted.
4. Connect an Android phone with USB debugging enabled, or use Android Studio's APK build menu.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated APK on the phone.

Target: Android 8.0+ (API 26+), tested configuration target Android 15/API 35. On Android 12, grant overlay permission and screen-capture permission when prompted.

## Use
1. Open the app.
2. Grant "Display over other apps".
3. Tap "Start screen monitoring" and approve Android's screen-capture prompt.
4. Switch to Chrome and open the game.
5. The floating panel displays detected results and historical frequencies.
6. Return to the app and tap "Stop monitoring" to end capture.

## Privacy
No network permission is requested. Result records are stored in the app's private SharedPreferences and are not uploaded.
