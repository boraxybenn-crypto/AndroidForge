package com.example.icefishing

import android.content.Context

object ResultHistory {
    private const val PREFS = "results"
    fun add(context: Context, category: String, multiplier: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString("rows", "") ?: ""
        val row = "${System.currentTimeMillis()}|$category|$multiplier"
        prefs.edit().putString("rows", (old + row + "\\n").takeLast(100_000)).apply()
    }
    fun stats(context: Context): Map<String, Int> {
        val rows = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("rows", "") ?: ""
        val counts = mutableMapOf("LIL' BLUES" to 0, "BIG ORANGES" to 0, "HUGE REDS" to 0)
        rows.lineSequence().forEach { line ->
            val category = line.split("|").getOrNull(1)
            if (category in counts) counts[category!!] = counts.getValue(category) + 1
        }
        return counts
    }
}
