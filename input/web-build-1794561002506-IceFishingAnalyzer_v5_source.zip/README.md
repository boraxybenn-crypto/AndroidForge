# Ice Fishing Analyzer v5 — experimental Android source

This archive is an Android Studio source project, **not an APK**. It has not been compiled or device-tested in this environment.

## Included prototype features
- User-approved Android MediaProjection screen capture.
- Foreground service and floating overlay (requires Android's "Display over other apps" permission).
- On-device ML Kit text recognition; no network permission is declared.
- Historical counters for the three fish labels and separate OCR multiplier buckets for Leaf and Fish.
- OCR is throttled to about one frame every 1.2 seconds.
- A candidate is accepted only after the same category/multiplier OCR fingerprint appears in three sampled frames.
- Label and multiplier must appear on the same OCR text line to reduce cross-matching.

## Critical limitations
- The game screenshots show multiplier labels printed on wheel segments, not a clearly isolated final-result panel. OCR may read a passing wheel segment and mistakenly count it as an outcome.
- The leafs are graphics, not the words "leaf" or "leaves". This prototype therefore **does not reliably recognise leaf symbols or their multiplier association**. It only detects a Leaf result if OCR actually sees the word leaf/leaves on the same line as a multiplier.
- Fish multipliers are also not validated as completed-round results. Same-line matching and frame stability reduce some false matches but do not establish that the wheel has stopped or identify the winning segment.
- The app does not access the casino backend, hidden RNG, account, or game session data. It cannot predict future outcomes or provide a betting advantage.
- Do not use the counts for wagering decisions. Treat all detections as experimental OCR observations, not verified game results.
- Screen capture can expose everything visible on the phone. Start it only when comfortable; capture is processed locally by ML Kit. Android requires explicit consent each time.
- The overlay is removed when the service is stopped. Use the app's Stop monitoring button to end capture.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**. The project targets Java/Kotlin 17 and Android SDK 35 (minimum Android 8/API 26). No APK is included.

## Test safely
First test with ordinary screenshots or non-wagering observation. Compare every OCR detection with a manually verified completed result. If the game does not show an unambiguous completed-result label in visible text, this OCR-only approach cannot reliably count outcomes; a result-region/symbol detector and further calibration would be needed.
